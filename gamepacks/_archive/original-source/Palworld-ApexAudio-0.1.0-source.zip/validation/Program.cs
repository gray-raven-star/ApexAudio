using System.Diagnostics;
using System.IO.MemoryMappedFiles;
using System.Security.Cryptography;
using System.Text.Json;
using ApexAudio.Contracts;
using ApexAudio.Core;

// Real-game validation only. It uses the shipped host protocol and reads
// capture mappings. Generated/offline audio is never passed off as game PCM.
string packPath=Path.GetFullPath(args[0]); int pid=int.Parse(args[1]);
string reportPath=Path.GetFullPath(args[2]);
var store=new PackageStore(Path.Combine(Path.GetDirectoryName(reportPath)!,"suite-install"));
var pack=store.Install(packPath);
var phases=new List<object>(); var errors=new List<string>(); object gate=new();
var tracks=new Dictionary<string,(long packets,long frames,float peak,string first)>();
await using var client=new AdapterClient();
client.Failed+=message=>{lock(gate)errors.Add(message);};
client.Audio+=packet=>{
    string id=client.Groups[(int)packet.GroupIndex].Id;
    lock(gate){var prev=tracks.GetValueOrDefault(id); tracks[id]=(prev.packets+1,prev.frames+packet.Frames,Math.Max(prev.peak,packet.Peak),prev.first??Convert.ToHexString(SHA256.HashData(packet.Pcm)));}
};
await client.Launch(pack);
using var process=Process.GetProcessById(pid);
await client.Connect(pid,process.MainModule?.FileName);
var source=await client.Call<FeedbackSource>("GetFeedbackSource");
using var mapping=MemoryMappedFile.OpenExisting(source.MappingName,MemoryMappedFileRights.Read);
using var view=mapping.CreateViewAccessor(0,3150488,MemoryMappedFileAccess.Read);
async Task<object> Measure(string label,int milliseconds){
    int before=view.ReadInt32(80); await Task.Delay(milliseconds);
    int after=view.ReadInt32(80); float peak=0; int consistent=0;
    for(int i=Math.Max(before,after-64);i<after;i++){
        long start=104L+(i%64)*16408L; int sequence=view.ReadInt32(start);
        if((sequence&1)!=0)continue;
        int frames=view.ReadInt32(start+4);
        if(frames is <1 or >2048)continue;
        float blockPeak=0;
        for(int f=0;f<frames;f++){
            blockPeak=Math.Max(blockPeak,Math.Abs(view.ReadSingle(start+24+f*4)));
            blockPeak=Math.Max(blockPeak,Math.Abs(view.ReadSingle(start+24+2048*4+f*4)));
        }
        if(view.ReadInt32(start)!=sequence)continue;
        consistent++;peak=Math.Max(peak,blockPeak);
    }
    return new{label,publishedBlocks=after-before,consistentBlocks=consistent,peak};
}
await client.Call<AdapterStatus>("SetFeedbackGroups",new CaptureRequest([]));
phases.Add(await Measure("empty-feedback",1200));
await client.Call<AdapterStatus>("SetFeedbackGroups",new CaptureRequest(["3803692087"]));
phases.Add(await Measure("master-feedback",1200));
await client.Call<AdapterStatus>("SetFeedbackGroups",new CaptureRequest([]));
phases.Add(await Measure("cleared-feedback",1200));
await client.Call<AdapterStatus>("SetFeedbackGroups",new CaptureRequest(["412724365"]));
phases.Add(await Measure("bgm-feedback",1200));
await client.Call<AdapterStatus>("SetFeedbackGroups",new CaptureRequest([]));
await Task.Delay(2000);
var statusBefore=await client.Call<AdapterStatus>("GetStatus");
await client.Call<AdapterStatus>("StopCapture");
phases.Add(new{label="stop-capture",status=await client.Call<AdapterStatus>("GetStatus")});
await client.Call<AdapterStatus>("StartCapture",new CaptureRequest(client.Groups.Where(g=>g.HasPcm).Select(g=>g.Id).ToArray()));
await Task.Delay(1200);
phases.Add(new{label="restart-capture",status=await client.Call<AdapterStatus>("GetStatus")});
await client.Call<AdapterStatus>("Disconnect");
phases.Add(new{label="disconnect",status=await client.Call<AdapterStatus>("GetStatus"),mappingActive=view.ReadInt32(16)});
await client.Connect(pid,process.MainModule?.FileName);
await Task.Delay(1800);
phases.Add(new{label="reconnect",status=await client.Call<AdapterStatus>("GetStatus"),mappingActive=view.ReadInt32(16)});
await client.Call<AdapterStatus>("Disconnect");
var finalStatus=await client.Call<AdapterStatus>("GetStatus");
object report;
lock(gate)report=new{packId=pack.Manifest.Id,targetSha256=pack.Manifest.Games[0].Sha256,gameProcessId=pid,phases,statusBefore,finalStatus,groups=client.Groups,tracks=tracks.Select(t=>new{id=t.Key,packets=t.Value.packets,frames=t.Value.frames,peak=t.Value.peak,firstPayloadSha256=t.Value.first}).ToArray(),errors,limitations="Activity-dependent measurements. PCM proves actual transport, not semantic names. No physical controller or X-Haptics output is started."};
File.WriteAllText(reportPath,JsonSerializer.Serialize(report,Wire.Json));
Console.WriteLine(JsonSerializer.Serialize(report,Wire.Json));
