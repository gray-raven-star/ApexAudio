"""Read unencrypted UE Pak v11 indexes; extract only requested metadata files.
Format reference: CUE4Parse/UE4/Pak/{PakFileReader.cs,Objects/FPakEntry.cs}.
No game file is changed. No encryption or proprietary compression is bypassed.
"""
import argparse, ctypes, hashlib, io, json, pathlib, struct

class Reader:
    def __init__(self, data): self.f = io.BytesIO(data)
    def read(self, n):
        b = self.f.read(n)
        if len(b) != n: raise ValueError('Truncated metadata')
        return b
    def value(self, fmt): return struct.unpack('<'+fmt, self.read(struct.calcsize('<'+fmt)))[0]
    def string(self):
        n = self.value('i')
        if not -65536 < n < 65536: raise ValueError('Invalid FString size')
        return self.read(n if n >= 0 else -n*2).decode('utf-8' if n>=0 else 'utf-16le').rstrip('\0')

def inspect(pak, output, targets, ooz=None):
    out = pathlib.Path(output); out.mkdir(parents=True, exist_ok=True)
    with open(pak, 'rb') as f:
        f.seek(-221, 2); footer = f.read(221)
        if footer[16] != 0: raise ValueError('Encrypted index is unsupported')
        magic, version, pos, size = struct.unpack_from('<IIqq', footer, 17)
        if magic != 0x5a6f12e1 or version != 11: raise ValueError('Only standard Pak v11 supported')
        def block(at, n, digest):
            if not 0<n<64*1024*1024: raise ValueError('Metadata exceeds bounded read limit')
            f.seek(at); data=f.read(n)
            if len(data)!=n or hashlib.sha1(data).digest()!=digest: raise ValueError('Index SHA1 mismatch')
            return data
        r=Reader(block(pos,size,footer[41:61])); mount=r.string(); count=r.value('i'); r.read(8)
        if r.value('I') != 1: raise ValueError('Missing path hash index')
        r.read(36)
        if r.value('I') != 1: raise ValueError('Missing directory index')
        dpos=r.value('q'); dsize=r.value('q'); dhash=r.read(20)
        enc=Reader(r.read(r.value('i')))
        nonencoded=r.value('i')
        if nonencoded: raise ValueError('Non-encoded entries unsupported')
        d=Reader(block(dpos,dsize,dhash)); files=[]
        for _ in range(d.value('i')):
            folder=d.string()
            for _ in range(d.value('i')):
                name=d.string(); loc=d.value('i'); path=mount+folder+name
                if loc == -2147483648: continue
                if loc<0: raise ValueError('Unexpected non-encoded entry')
                enc.f.seek(loc); bits=enc.value('I')
                if bits&63==63: enc.read(4)
                method=bits>>23&63
                offset=enc.value('I' if bits>>31&1 else 'Q')
                usize=enc.value('I' if bits>>30&1 else 'Q')
                csize=enc.value('I' if bits>>29&1 else 'Q') if method else usize
                blocks=bits>>6&65535; encrypted=bool(bits>>22&1)
                header=53+(4+blocks*16 if method else 0)
                entry=dict(path=path,offset=offset,size=usize,compressedSize=csize,method=method,encrypted=encrypted,headerSize=header)
                files.append(entry)
                if any(path.casefold().endswith(t.casefold()) for t in targets):
                    if encrypted or (method and not ooz):
                        entry['extractionStatus']='requires compression support' if method else 'encrypted; unsupported'
                        continue
                    if usize>16*1024*1024: raise ValueError('Metadata file exceeds extraction limit')
                    f.seek(offset); rawheader=f.read(header)
                    disk_csize,disk_usize,disk_method=struct.unpack_from('<QQI',rawheader,8)
                    if (disk_csize,disk_usize,disk_method)!=(csize,usize,method): raise ValueError('Entry metadata mismatch')
                    f.seek(offset+header); packed=f.read(csize)
                    if len(packed)!=csize: raise ValueError('Truncated file')
                    if method:
                        if method!=1: raise ValueError('Only Oodle method 1 supported')
                        lib=ctypes.CDLL(str(pathlib.Path(ooz).resolve())); decompress=lib.OozDecompress
                        decompress.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_void_p,ctypes.c_size_t]; decompress.restype=ctypes.c_int
                        decoded=[]
                        for b in range(blocks):
                            start,end=struct.unpack_from('<QQ',rawheader,52+b*16)
                            expected=usize if blocks==1 else min(usize-sum(map(len,decoded)),(bits&63)<<11)
                            f.seek(offset+start); src=f.read(end-start); dst=ctypes.create_string_buffer(expected+64)
                            result=decompress(src,len(src),dst,expected)
                            if result!=expected: raise ValueError('Oodle decompression failed')
                            decoded.append(dst.raw[:expected])
                        data=b''.join(decoded)
                    else: data=packed
                    if len(data)!=usize: raise ValueError('Decoded size mismatch')
                    dest=out/name; dest.write_bytes(data)
                    entry['extractedSha256']=hashlib.sha256(data).hexdigest()
        evidence=dict(version=version,mount=mount,fileCount=count,indexSha1=footer[41:61].hex(),directorySha1=dhash.hex(),entries=files)
        (out/'pak-index.json').write_text(json.dumps(evidence,indent=2,ensure_ascii=False),encoding='utf-8')
        candidates=[x for x in files if any(s in x['path'].lower() for s in ['init.bnk','soundbanksinfo','projectinfo','wwise','audiokinetic','soundbank'])]
        print(json.dumps(dict(version=version,fileCount=count,parsed=len(files),audioMetadataCandidates=candidates),indent=2))

if __name__=='__main__':
    a=argparse.ArgumentParser(); a.add_argument('pak'); a.add_argument('output'); a.add_argument('targets',nargs='*'); a.add_argument('--ooz'); args=a.parse_args()
    inspect(args.pak,args.output,args.targets,args.ooz)
