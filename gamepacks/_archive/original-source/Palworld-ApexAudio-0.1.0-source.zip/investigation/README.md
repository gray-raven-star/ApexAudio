# 本次独立调查的复现说明

运行包构建见根 README。这里的工具只用于开发调查，不随适配器运行。

1. 从用户提供的完整 DevKit 运行 Setup 和 inspect，检查当前游戏主程序、资源候选及运行中的主模块导出。主程序实际含有 Wwise 正式导出；随游戏附带的 AkSoundEngineDLL.dll 未在本次运行中加载，不能误用它的摘要作为音频实例。
2. 用 prepare-ooz.ps1 -Compiler <Zig路径> 下载公开原始源码并构建临时解压 DLL。来源和许可见根 DEPENDENCIES.md；不用任何已有游戏工具缓存。原始源摘要在 evidence/dependency-hashes.json，可检查上游变更。
3. 用 Python 3.12 调用 pak_metadata.py <游戏Pak路径> <临时输出目录> Init.bnk Wwise.uplugin --ooz <本步生成的ooz.dll>。工具仅支持未加密的标准 v11 Pak，校验主索引和目录索引 SHA1，限制单次读取尺寸，不整包解压。原始游戏资源不要随包发布。
4. 从 https://github.com/bnnm/wwiser 下载公开源码，在独立目录运行 `python wwiser.py <Init.bnk> -d xml -dn <输出前缀>`。不要放入名称数据库。实际观察为 bank v150，Wwise.uplugin 的 VersionName 为 2023.1.3.8471.2970。
5. CAkBus 的 ulID 为总线 ID，OverrideBusId 为父组；BusInitialFxParams 下的 uFXIndex 为已用效果槽。本次所有普通总线 slot 3 均为空。CAkAuxBus 不当作普通总线采集。路由和槽位证据见 evidence/bus-routing.json；gamepacks/palworld/game.json 是本次生成的定义。
6. 使用 Wwise 的小写 FNV-1 算法（初值 2166136261；每字节先乘 16777619 再 XOR）核对英文名称候选和游戏 EXE 字符串。匹配不替代逐动作试听；未知组保持编号。
7. 运行根目录构建命令；用 DevKit check --launch 校验结构和协议，native-check --entry CaptureSelfTest 做离线透传自测。它们不证明游戏采集已成功。
8. 在用户开启的游戏中运行 DevKit capture --allow-game-connection；本次得到真实非零 PCM 和不同分组摘要。完整验证阶段见 evidence/validation-report.json。

可选验证程序：在根目录 `dotnet publish validation/Validation.csproj -c Release -o artifacts/validation --configfile NuGet.Config`，随后 `artifacts/validation/Validation.exe <gpack路径> <用户已启动游戏的PID> <报告路径>`。它会加载正常采集模块、测试选择和重连，需要已获授权的游戏进程；不启动 X-Haptics 或物理输出。它是开发验证工具，不是日常使用所需。

本次复用的 Wwise 后端源码与 DevKit 完全一致；没有改动宿主代码。新增内容为游戏定义、预设、元数据读取器、验证程序和文档。原始游戏银行、Pak、EXE、媒体、原始目录索引和第三方解压 DLL 均未分发。
