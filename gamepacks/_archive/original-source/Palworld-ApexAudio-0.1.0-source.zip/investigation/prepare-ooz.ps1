param([Parameter(Mandatory)][string]$Compiler)
$ErrorActionPreference = 'Stop'
$directory = Join-Path $PSScriptRoot 'ooz-build'
New-Item -ItemType Directory -Path $directory -Force | Out-Null
foreach ($name in @('kraken.cpp','bitknit.cpp','lzna.cpp','stdafx.h','targetver.h','README.md')) {
    Invoke-WebRequest -Uri ('https://raw.githubusercontent.com/powzix/ooz/master/' + $name) -OutFile (Join-Path $directory $name)
}
$text = Get-Content -LiteralPath (Join-Path $directory 'kraken.cpp') -Raw
$marker = '// The decompressor will write outside'
if ($text.IndexOf($marker) -lt 0) { throw 'Upstream layout changed; review before building.' }
$text = $text.Substring(0,$text.IndexOf($marker))
$text += "`nextern `"C`" __declspec(dllexport) int OozDecompress(const byte* src, size_t srclen, byte* dst, size_t dstlen) { return Kraken_Decompress(src, srclen, dst, dstlen); }`n"
Set-Content -LiteralPath (Join-Path $directory 'kraken-library.cpp') -Value $text -Encoding utf8
Set-Content -LiteralPath (Join-Path $directory 'targetver.h') -Value '#pragma once' -Encoding utf8
$env:ZIG_GLOBAL_CACHE_DIR = Join-Path $directory 'zig-cache'
$env:ZIG_LOCAL_CACHE_DIR = Join-Path $directory 'zig-local-cache'
& $Compiler c++ -target x86_64-windows-gnu -O2 -shared '-msse4.1' (Join-Path $directory 'kraken-library.cpp') (Join-Path $directory 'bitknit.cpp') (Join-Path $directory 'lzna.cpp') -o (Join-Path $directory 'ooz.dll')
if ($LASTEXITCODE -ne 0) { throw 'ooz build failed.' }
Write-Output (Join-Path $directory 'ooz.dll')
