import itertools,json,pathlib,re,runpy
# Additional finite candidates use current game's public resource-path words.
# This remains hash recovery, not a claim of an embedded original name table.
base=pathlib.Path('work/rise/evidence/name-candidate-leads.json')
matches=json.loads(base.read_text(encoding='utf-8'))
rows=json.loads(pathlib.Path('work/rise/evidence/buses.json').read_text()); ids={x['id'] for x in rows}
def fnv(s):
    v=2166136261
    for b in s.lower().encode('utf-8'):v=((v*16777619)^b)&0xffffffff
    return v
def add(s):
    i=fnv(s)
    if i not in ids:return
    item=dict(name=s,origin='finite hash recovery using current game resource-path vocabulary')
    if item not in matches.setdefault(str(i),[]):matches[str(i)].append(item)
prefixes=['PL','Wp','Foley','EM','EMS','Enemy','NPC','Dog','Airou','Otomo','Env','UI','SE','SFX','BGM','BGM_Quest','BGM_Lobby','BGM_Common','Event','Dialogue','Aux','Auxiliary','Impact','Gimmick','EC']
words=set(['Main','Master','VO','Voice','Action','Foot','Footstep','Footsteps','Move','Movement','Metal','Cloth','Equipment','Gear','Armor','Common','Others','Other','Body','Hit','Attack','Swish','Swing','Swipe','Woosh','Whoosh','Slash','Slashing','Knife','Sword','Impact','Bullet','Gun','Shot','Shell','Magic','Cannon','Arrow','Hitstop','Free','Normal','Critical','Head','Ear','Kiai','Damage','Dmg','Reaction','Motion','Event','Talk','Chat','Battle','Result','Map','Camp','Base','Wind','Water','Layer','Background','System','Com','Env','Enemy','Hunter','Monster','Player','Otomo','Self','My','Multi','Local','Non','Remote','FootStep','Foley','UI','SE','BGM','Music','Priority','Hi','Low','Mid','High','Sub','L','R','C','LS','RS','LFE','Master','Reverb','Return','Output','Spatial','Stereo','Mono','Ducking','Duck','NoPause','Pause','Demo','Voice','VO','Menu','Title','Ambient','Ambience','Mix','3D','2D','Play','All','Mute','Default','Option','Volume','OptionVolume','Option_Volume','Control','Scene','Shout','FootStep','Environmental','EM','PL','Object','Item','Shout','Jingle','SE','Volume','Direct','Post','Pre','Height','Order','Max','Medium','Large','Small','Min','S','M','Stage','Ground','FS','Step','Em_L','Em_S','Loud','Middle','Middle','Fell','Wall','Room','Cave','Indoor','Outdoor','Ducking_Master'])
paths=pathlib.Path('work/rise/sources/MHR_STM_Release.list').read_text().splitlines()
for path in paths:
    if '/sound/asset/' not in path:continue
    for word in re.split(r'[/_.]',path):
        if 2<=len(word)<=18 and word.isalpha(): words.add(word)
words=sorted(words)
for prefix in prefixes:
    for word in words:
        for sep in ['_',' ','']:
            add(prefix+sep+word)
            add(prefix+sep+word+sep+'Master')
            add(prefix+sep+word+sep+'VO')
# A constrained second suffix for existing category names, rather than an
# unbounded Cartesian product over every word found in the executable.
for prefix in prefixes:
    for word in words:
        for end in ['Other','Main','Loop','OneShot','Attack','Move','Voice','SE','SFX','Normal','Demo','Event','Ducking','Volume','Pause','Base','Layer','Master']:
            add(prefix+'_'+word+'_'+end)
base.write_text(json.dumps(matches,indent=2,ensure_ascii=False),encoding='utf-8')
print('resource vocabulary words',len(words),'matched IDs',len(matches))
print('\n'.join(k+' '+', '.join(sorted({x['name'] for x in v})) for k,v in matches.items()))
