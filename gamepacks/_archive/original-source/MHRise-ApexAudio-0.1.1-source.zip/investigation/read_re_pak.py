"""Bounded RE Pak v4 metadata reader. Does not edit game files.
Format references: Ekey/REE.PAK.Tool PakUnpack, PakHash, Murmur3, PakCipher.
Only explicitly requested small metadata files are extracted.
"""
import argparse, hashlib, json, pathlib, re, struct, sys, zlib
sys.path.insert(0,str(pathlib.Path(__file__).parent/'python-deps'))

def rol(x,n): return ((x<<n)|(x>>(32-n)))&0xffffffff
def murmur(name):
    data=name.encode('utf-16le'); h=0xffffffff
    for i in range(0,len(data)//4*4,4):
        k=int.from_bytes(data[i:i+4],'little'); k=k*0xcc9e2d51&0xffffffff
        k=rol(k,15)*0x1b873593&0xffffffff; h^=k; h=(rol(h,13)*5+0xe6546b64)&0xffffffff
    tail=data[len(data)//4*4:]
    if tail:
        k=int.from_bytes(tail,'little')*0xcc9e2d51&0xffffffff
        h^=rol(k,15)*0x1b873593&0xffffffff
    h^=len(data); h^=h>>16; h=h*0x85ebca6b&0xffffffff; h^=h>>13; h=h*0xc2b2ae35&0xffffffff; h^=h>>16
    return h

def extract(pak,output,names,cipher_reference):
    dest=pathlib.Path(output); dest.mkdir(parents=True,exist_ok=True)
    candidates={(murmur(n.lower()),murmur(n.upper())):n for n in names}
    with open(pak,'rb') as f:
        magic,major,minor,flags,count,fingerprint=struct.unpack('<IBBHII',f.read(16))
        if magic!=0x414b504b or major!=4 or minor!=0 or flags not in [0,8]: raise ValueError('Unsupported Pak header')
        if count>500000: raise ValueError('Index exceeds bound')
        table=f.read(count*48)
        if len(table)!=count*48: raise ValueError('Truncated index')
        if flags==8:
            # Read the public format constant from the separately downloaded
            # original implementation; no secret or locally cached key is used.
            code=pathlib.Path(cipher_reference).read_text(encoding='utf-8-sig')
            modulus_text=code.split('lpModulus = {',1)[1].split('};',1)[0]
            modulus=bytes(int(v,16) for v in re.findall(r'0x([0-9A-Fa-f]{2})',modulus_text))
            wrapped=f.read(128)
            key=pow(int.from_bytes(wrapped,'little'),65537,int.from_bytes(modulus,'little')).to_bytes(129,'little')
            table=bytes(v^((i+key[i%32]*key[i%29])&255) for i,v in enumerate(table))
        f.seek(0,2); length=f.tell(); entries=[]; found=[]
        for i in range(count):
            lower,upper,offset,compressed,size,attributes,checksum=struct.unpack_from('<IIQQQQQ',table,i*48)
            if offset+compressed>length: raise ValueError(f'Invalid index entry {i}')
            name=candidates.get((lower,upper))
            if not name: continue
            compression=attributes&15; encryption=(attributes>>16)&255
            entry=dict(path=name,index=i,offset=offset,compressedSize=compressed,size=size,compression=compression,encryption=encryption,checksum=f'{checksum:016X}')
            if size>16*1024*1024 or compressed>16*1024*1024: raise ValueError('Requested metadata exceeds 16 MiB bound')
            if encryption: raise ValueError('Resource encryption is unsupported')
            f.seek(offset); data=f.read(compressed)
            if compression==1: data=zlib.decompress(data,-15)
            elif compression==2:
                import zstandard
                data=zstandard.ZstdDecompressor().decompress(data,max_output_size=size)
            elif compression!=0: raise ValueError(f'Unsupported compression {compression}')
            if len(data)!=size: raise ValueError('Decoded size mismatch')
            target=dest/pathlib.PurePosixPath(name).name; target.write_bytes(data)
            entry['sha256']=hashlib.sha256(data).hexdigest(); entry['first32']=data[:32].hex()
            found.append(entry)
        report=dict(pak=pathlib.Path(pak).name,major=major,minor=minor,flags=flags,fileCount=count,indexSha256=hashlib.sha256(table).hexdigest(),files=found)
        (dest/'extraction.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
        print(json.dumps(report,indent=2))
        return report

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('pak'); p.add_argument('output'); p.add_argument('--cipher-reference',required=True); p.add_argument('names',nargs='+'); a=p.parse_args()
    extract(a.pak,a.output,a.names,a.cipher_reference)
