"""Naming-only MHRise update. Hash recovery is explicitly reference labeling.
Does not alter native code, routes, capture slots, hashes, or game files.
"""
import copy,hashlib,json,pathlib,shutil,zipfile
root=pathlib.Path.cwd(); evidence=root/'work/rise/evidence'
leads=json.loads((evidence/'name-candidate-leads.json').read_text(encoding='utf-8'))
def fnv(s):
    v=2166136261
    for b in s.lower().encode('utf-8'):v=((v*16777619)^b)&0xffffffff
    return v
leads.setdefault('805203703',[]).append(dict(name='Master Secondary Bus',origin='standard Wwise name candidate'))
# The displayed Chinese text is a translation/reference label, not an assertion
# that a Chinese name was present in the game bank.
translations={
'master audio bus':'主混音（仅层级，不采集）','master secondary bus':'次级输出',
'main_audio_bus':'主音频','se_master':'音效总组','auxiliary_master':'辅助混音汇总',
'sfx_master':'通用音效','enemy_master':'怪物音效总组','ems':'怪物音效 · EMS','em':'怪物音效 · EM',
'em_vo':'怪物语音 · EM','ems_vo':'怪物语音 · EMS','em_fo':'怪物动作拟音 · EM','ems_fo':'怪物动作拟音 · EMS',
'em_fx':'怪物效果声 · EM','ems_fx':'怪物效果声 · EMS','otomo_master':'随从音效总组',
'airou_master':'随从猫','airou_other':'随从猫其他音效','airou_action_vo':'随从猫动作语音',
'dog_master':'随从狗','dog_other':'随从狗其他音效','dog_action_vo':'随从狗动作语音',
'ec_master':'环境生物音效','gimmick_master':'机关与场景互动','impact_master':'撞击与命中音效',
'env_master':'环境声','env_layer':'环境声叠加层','env_base':'基础环境声','env_wind':'风声',
'npc_master':'NPC 音效总组','npc_se':'NPC 动作音效','npc_vo':'NPC 语音',
'wp_ducking':'武器混音避让','pl_master':'玩家音效总组','pl_wp':'玩家武器','wp_other':'武器其他音效',
'wp_impact':'武器命中','wp_whoosh':'武器挥动','pl_fx':'玩家效果声','pl_action_vo':'玩家动作语音',
'pl_foley':'玩家动作拟音','foley_movement':'移动拟音','foley_footsteps':'脚步','pl_other':'玩家其他音效',
'ui_master_pause':'暂停界面音效','ui_other':'界面其他音效','ui_loading':'加载界面音效',
'ui_master':'界面音效总组','ui_info':'界面提示音',
'dialogue_master':'对白总组','pl_situation_vo':'玩家情境语音','dialogue_npc_chat':'NPC 闲聊对白',
'dialogue_event_other':'事件其他对白','event_bgm_master':'事件音乐','event_se_master':'事件音效',
'event_main':'主要事件音效','event_otomo':'事件随从音效','event_pl_voice':'事件玩家语音',
'bgm_master':'背景音乐总组','bgm_quest_master':'任务音乐总组','bgm_quest_battle':'任务战斗音乐',
'bgm_quest_demo':'任务演出音乐','bgm_quest_meat':'任务音乐 · meat','bgm_quest_map':'任务场景音乐',
'bgm_quest_result':'任务结算音乐','bgm_quest_jingle':'任务提示乐','bgm_lobby_master':'大厅音乐总组',
'bgm_lobby_jingle':'大厅提示乐','bgm_lobby':'大厅音乐','bgm_lobby_vo':'大厅音乐人声',
'bgm_common_master':'通用音乐总组','bgm_common_jingle':'通用提示乐',
'aux_init':'辅助组初始化','camp':'营地'
}
category_roots={3803692087:'混音输出',805203703:'混音输出',253003338:'混音输出',814663814:'通用音效',
392537532:'辅助混音',3205032327:'通用音效',50050244:'怪物',1819748195:'怪物',580059306:'怪物',
957788960:'随从',1933058324:'随从猫',3663448410:'随从狗',1090403738:'环境生物',1267086631:'场景互动',
2154761356:'撞击与命中',2472534735:'环境',2493685259:'NPC',2567740528:'武器',3223516310:'玩家',
264685801:'武器',3036395753:'玩家动作拟音',2414365428:'对白',509070426:'玩家语音',
926848091:'界面',1455882868:'界面',2563992102:'界面',3075009468:'界面',3145001837:'事件音乐',
3179867851:'事件音效',3513968129:'玩家语音',4141759354:'背景音乐'}
archive=root/'outputs/MHRise-0.1.0/MHRise-ApexAudio-0.1.0.gpack'
stage=root/'work/rise/named-stage';stage.mkdir(exist_ok=True)
with zipfile.ZipFile(archive) as z:
    for item in z.infolist():
        p=(stage/item.filename).resolve()
        if not p.is_relative_to(stage.resolve()):raise ValueError('Unsafe archive entry')
    z.extractall(stage)
old=json.loads((stage/'game.json').read_text(encoding='utf-8-sig'));game=copy.deepcopy(old)
byid={b['id']:b for b in game['buses']}
mapping=[];recovered={}
for key,values in leads.items():
    lower={x['name'].lower() for x in values}
    if len(lower)!=1:continue # no arbitrary choice when different names collide
    normalized=next(iter(lower));id=int(key)
    if id not in byid or normalized not in translations:continue
    assert fnv(normalized)==id
    # Prefer a literal observed string when present. Otherwise the case is only
    # a readable reconstruction; Wwise's hash does not preserve capitalization.
    direct=[x for x in values if x['origin'].startswith('current game settings metadata')]
    canonical=(direct or values)[0]['name'];cn=translations[normalized]
    recovered[id]=(canonical,cn)
    source='游戏音频设置元数据字符串与 Wwise FNV 一致；中文为参考释义' if direct else '有限词汇按 Wwise FNV 恢复的参考名称；原始大小写未知，未逐组试听确认'
    if id in [3803692087,805203703]:source='标准 Wwise 名称与 FNV 一致；输出用途未额外实测'
    byid[id]['name']=cn if id==3803692087 else f'{cn}（{canonical}）'
    byid[id]['nameSource']=source
    mapping.append(dict(id=id,recoveredName=canonical,chineseReference=cn,kind='metadata-string-hash-match' if direct else 'hash-recovered-reference',origins=sorted({x['origin'] for x in values}),parentId=byid[id]['parent'],auxiliary=byid[id]['auxiliary'],notAuditioned=True))
def category(id):
    seen=set()
    while id and id not in seen:
        seen.add(id)
        if id in category_roots:return category_roots[id]
        id=byid.get(id,{}).get('parent',0)
    return '未分类'
inherited=[]
for bus in game['buses']:
    bus['category']=category(bus['id'])
    if bus['id'] in recovered:continue
    parent=bus['parent'];seen=set();ancestor=None
    while parent and parent not in seen:
        seen.add(parent)
        if parent in recovered and parent not in [3803692087,253003338]:ancestor=parent;break
        parent=byid.get(parent,{}).get('parent',0)
    if ancestor:
        bus['name']=f"{recovered[ancestor][1]} · 未命名组 {bus['id']}"
        bus['nameSource']=f'具体名称未恢复；按实际父子路由归入父组 {ancestor} 的参考类别，未逐组试听确认'
        inherited.append(dict(id=bus['id'],ancestor=ancestor))
    else:
        bus['name']=f"未命名混音组 {bus['id']}"
        bus['nameSource']='Init.bnk 原始总线编号；未找到可靠名称参考'
# Freeze the acquisition-related surface: only name/nameSource/category may change.
for before,after in zip(old['buses'],game['buses']):
    assert {k:v for k,v in before.items() if k not in ['name','nameSource','category']}=={k:v for k,v in after.items() if k not in ['name','nameSource','category']}
assert {k:v for k,v in old.items() if k!='buses'}=={k:v for k,v in game.items() if k!='buses'}
ordinary=[b for b in game['buses'] if not b['auxiliary']]
named=sum(b['id'] in recovered for b in ordinary)
summary=dict(version='0.1.1',ordinaryTotal=len(ordinary),referenceNamed=named,stillNumbered=len(ordinary)-named,metadataStringMatched=sum(not x['auxiliary'] and x['kind']=='metadata-string-hash-match' for x in mapping),mapping=sorted(mapping,key=lambda x:x['id']),inheritedCategoryLabels=inherited,method='Names recovered using finite vocabulary, current game settings strings, Wwise lowercase FNV-1, plus actual bank hierarchy. A hash match is reference evidence, not an original name table or a substitute for auditioning.',nativeCaptureUnchanged=True,baseVersion='0.1.0')
assert named==72,(named,'Unexpected naming count')
(evidence/'name-restoration.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
(stage/'evidence/name-restoration.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
(stage/'game.json').write_text(json.dumps(game,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
manifest=json.loads((stage/'manifest.json').read_text(encoding='utf-8-sig'));manifest['version']='0.1.1'
manifest['description']='Steam build 17920865；名称完善版：143 条普通总线中 72 条补充参考名，其余按父组归类并保留编号；142 条采集逻辑与 0.1.0 相同。'
(stage/'manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
readme=(stage/'README.md').read_text(encoding='utf-8')
readme=readme.replace('适配包 0.1.0','适配包 0.1.1').replace('MHRise-ApexAudio-0.1.0.gpack','MHRise-ApexAudio-0.1.1.gpack')
readme=readme.replace('- 没有可靠名称依据的总线保留编号，不编造武器、怪物、玩家等语义标签。','- 143 条普通总线中，72 条有参考名称，包括玩家武器/挥动/命中/脚步、怪物音效/语音、随从猫狗、NPC、界面、对白和多类音乐。其余 71 条保留编号，能按父组归类的标为“某类 · 未命名组”。\n- 参考名通过当前游戏设置字符串、有限资源词汇组合与 Wwise FNV 对应，并结合实际总线层级核对。只有少量直接来自设置字符串；多数是哈希恢复候选，不是从原始总线名称表提取，也没有逐组试听确认。英文大小写不保证与原作一致。详情见 evidence/name-restoration.json。')
readme=readme.replace('## 验证范围','## 本次更新\n\n本版只更新显示名称、名称来源和分类，采集模块、音频路由、效果槽、游戏摘要和反馈默认关闭状态均与 0.1.0 一致。未额外连接游戏。导入前先断开旧连接，导入后重新连接以刷新组名；自己设置过的名称可能优先显示，可切回作者初始配置查看。\n\n## 验证范围')
(stage/'README.md').write_text(readme,encoding='utf-8')
report=json.loads((stage/'validation-report.json').read_text(encoding='utf-8'))
report['packVersion']='0.1.1';report['namingUpdate']=summary
report['stages']['semantics']='72 ordinary groups have reference names (finite hash recovery and some current-game settings strings); 71 retain numeric identifiers and optional ancestor-based reference labels. No exhaustive audition performed.'
report['captureValidationVersion']='0.1.0; native module and every acquisition field are identical in 0.1.1'
report['limitations']=[s for s in report['limitations'] if '具体动作语义' not in s]
report['limitations'].append('名称多数是哈希恢复候选，不保证原作大小写或逐项语义；剩余 71 条普通总线尚未恢复名称。')
(stage/'validation-report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
definition=root/'work/rise/named-definition';definition.mkdir(exist_ok=True)
for p in stage.iterdir():
    if p.name in ['manifest.json','game.json','README.md','DEPENDENCIES.md','validation-report.json']:shutil.copy2(p,definition/p.name)
for dirname in ['presets','evidence']:shutil.copytree(stage/dirname,definition/dirname,dirs_exist_ok=True)
out=root/'outputs/MHRise-0.1.1';out.mkdir(exist_ok=True)
shutil.copy2(stage/'README.md',out/'使用说明.md');shutil.copy2(stage/'validation-report.json',out/'validation-report.json')
lines=['# 崛起 0.1.1 名称参考对照','', '名称以参考用途提供，哈希恢复不等于原始名称表或逐项试听确认。','', '| 总线 ID | 显示参考名称 | 恢复英文 | 依据 |','|---|---|---|---|']
for x in sorted(mapping,key=lambda x:x['id']):
    if x['auxiliary']:continue
    lines.append(f"| {x['id']} | {x['chineseReference']} | {x['recoveredName']} | {'设置字符串＋哈希' if x['kind']=='metadata-string-hash-match' else '哈希恢复参考'} |")
(out/'名称对照.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k not in ['mapping','inheritedCategoryLabels']},ensure_ascii=False))
