import json,pathlib
rows=json.loads(pathlib.Path('work/rise/evidence/buses.json').read_text())
matches=json.loads(pathlib.Path('work/rise/evidence/name-candidate-leads.json').read_text(encoding='utf-8'))
children={}
for row in rows:
    if row['kind']=='CAkBus':children.setdefault(row['parent'],[]).append(row)
def show(parent,depth=0):
    for row in children.get(parent,[]):
        names=sorted({x['name'] for x in matches.get(str(row['id']),[])})
        print('  '*depth+str(row['id'])+' '+', '.join(names))
        show(row['id'],depth+1)
show(0)
