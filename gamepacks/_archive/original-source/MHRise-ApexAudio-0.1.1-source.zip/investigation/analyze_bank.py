import collections, json, pathlib, xml.etree.ElementTree as ET
root=ET.parse('work/rise/metadata/Init-dump.xml').getroot()
counts=collections.Counter(x.get('name') for x in root.findall('.//object'))
rows=[]
for x in root.findall('.//object'):
    if x.get('name') not in ['CAkBus','CAkAuxBus']: continue
    i=int(x.find('./field[@name="ulID"]').get('value'))
    p=int(x.find('.//field[@name="OverrideBusId"]').get('value'))
    fx=x.find('.//object[@name="BusInitialFxParams"]')
    rows.append(dict(id=i,parent=p,kind=x.get('name'),used=[int(f.get('value')) for f in fx.findall('.//field[@name="uFXIndex"]')],hircOffset=int(x.find('./field[@name="ulID"]').get('offset'))))
pathlib.Path('work/rise/evidence/buses.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
print({k:v for k,v in counts.items() if k in ['CAkBus','CAkAuxBus','CAkFxShareSet']})
print('all effect slots used',sum(len(x['used'])==4 for x in rows if x['kind']=='CAkBus'))
print(json.dumps(rows[:12],indent=2))
