"""Hash candidates are leads only, never asserted to be extracted game names."""
import itertools,json,pathlib,re
def fnv(s):
    value=2166136261
    for b in s.lower().encode('utf-8'):value=((value*16777619)^b)&0xffffffff
    return value
rows=json.loads(pathlib.Path('work/rise/evidence/buses.json').read_text());ids={x['id'] for x in rows}
words=['Master','Bus','Audio','BGM','SE','SFX','UI','Voice','VO','Music','Ambient','Ambience','Environment','Env','Player','PL','Enemy','EM','Monster','Weapon','Wp','System','Sys','Main','Game','Volume','Output','Sound','All','Global','Root','Default','Effect','NPC','Otomo','Dialogue','Dialog','Demo','Movie','MovieVoice','Mastering','Map','Battle','Me','Com','Common','Stereo','Surround','VR','HDMI','Motion','Vibration','BgmVoice','Ducking','Action','Foot','Footstep','Foley','Item','Hit','Magic','Water','Reverb','Near','Far','Parent','Win','Steam','STM','Pc','Final','Gui','Sub','Device','Capture','Normal','Event','Title','InGame','bgm_quest','bgm_lobby','Binaural','Center','Obj','Priority','VolumeControl','Control','Mixer','Mix','Center','2D','3D']
words+=['AMB','Aux','Auxiliary','Filter','Dry','Wet','Out','In','Player1','Other','Others','Common','Com','Reverb','Rev','Effecter','Efcter','Cat','Dog','Palico','Palamute','Airou','Garu','Fs','Fstep','FootStep','Hit','Swing','Shell','Attack','Atk','Damage','Dmg','Move','Movement','Equip','Armor','Cloth','Cut','Slash','Impact','Shoot','Gun','Bow','Volume','Vol','Mute','Direct','Low','High','Mid','Level','LFE','Center','RE','Mix','Limiter','Compressor','Bass','Mastering','Dialogue','Narration','Stream','Streaming','Video','Efx','Obj','Gimmick','Gmk','Envcreature','EC','Enemy','EM','Em','Boss','Zako','Large','Small','Huge','S','L','Anim','Animation','Sound','Event','Evt','End','Opening','Ending','Cutscene','Quest','Lobby','Demo','Title','Loading','Init','Menu','Food','Hyakuryu','100r','Npc','Chat','Message','Information','Announce','Result','Village','Camp','Common','Layer','Local','Online','Self','Other','Remote','My','Me','M','Non','None','Headphone','Speaker','Stereo','EQ','Compressor','Ducker','Ducking','Dynamic','Static','RTPC','HDR','Camera','Distance','Zoom','Base','Main','Sub','Pause','Wind','Rain','Thunder','Nature','River','Sea','Flow','Forest','Snow','Fire','Rock','Grass','Air','Fall','Jump','Step','Landing','Loop','Shot','OneShot','Oneshot','Enemy1','Enemy2','Enemy3','Enemy4','Enemy5','Enemy6','Enemy7','Enemy8','Own','Enemy_Large','Enemy_Small','Monster_Large','Monster_Small','AUX','AUX_Master','BGM_Quest','BGM_Lobby','BGM_Common','SE_Reverb','Env_Reverb','Event_VO','Dialogue_VO']
words=list(dict.fromkeys(words))
matches={}
def add(s,origin):
    i=fnv(s)
    if i in ids:
        item=dict(name=s,origin=origin)
        if item not in matches.setdefault(str(i),[]):matches[str(i)].append(item)
for s in words:add(s,'explicit candidate vocabulary')
for sep in ['','_',' ','-']:
    for a,b in itertools.product(words,repeat=2):add(a+sep+b,'candidate word pair')
for prefix in ['Bus','Master','BGM','SE','Voice','SFX','Audio','Sound','Main','Root','EM','PL','NPC','Otomo','Enemy','Env','UI','Event','Dialogue','AMB','Aux','Wp']:
    for sep in ['','_',' ','-']:
        for a,b in itertools.product(words,repeat=2):add(sep.join([prefix,a,b]),'candidate prefix plus word pair')
for folder in pathlib.Path('work/rise/metadata').glob('settings-*'):
    for p in folder.glob('*.2'):
        data=p.read_bytes()
        for m in re.finditer(rb'(?:[ -~]\x00){2,160}',data):add(m.group().decode('utf-16le'),'current game settings metadata: '+p.name)
pathlib.Path('work/rise/evidence/name-candidate-leads.json').write_text(json.dumps(matches,indent=2,ensure_ascii=False),encoding='utf-8')
print('\n'.join(k+' '+', '.join(sorted({x['name'] for x in v})) for k,v in matches.items()))
print('IDs:',len(matches))
