import base64,hashlib,json,pathlib,struct
root=pathlib.Path.cwd(); definition=root/'work/devkit/gamepacks/mhrise'
rows=json.loads((root/'work/rise/evidence/buses.json').read_text())
bank=(root/'work/rise/metadata/patch/init.bnk.2.x64').read_bytes()
sha=json.loads((root/'work/rise/evidence/static.json').read_text(encoding='utf-8-sig'))['sha256']
buses=[]
for row in rows:
    auxiliary=row['kind']=='CAkAuxBus'
    free=[slot for slot in range(4) if slot not in row['used']]
    slot=max(free) if free and not auxiliary else -1
    row['captureSlot']=slot
    name='主混音（仅层级，不采集）' if row['id']==3803692087 else f"音频总线 {row['id']}"
    buses.append(dict(id=row['id'],parent=row['parent'],name=name,nameSource='原始 Init.bnk 总线编号；主混音名称为标准 Wwise FNV 对应',category='音频总线',auxiliary=auxiliary,slot=slot))
game=dict(backend='Wwise',title='怪物猎人：崛起 · Wwise 音频',gameSha256=sha,engineModule='MonsterHunterRise.exe',engineSha256=sha,bankVersion=140,bankHeader=base64.b64encode(bank[8:8+struct.unpack_from('<I',bank,4)[0]]).decode(),bankId=0x7a4d4800,sdkYear=2021,sdkSeries=1,captureFile='modules/ApexMHRiseWwiseCapture.dll',captureSha256='',buses=buses)
ids={x['id'] for x in buses};assert all(b['parent']==0 or b['parent'] in ids for b in buses)
assert not any(game['bankId']<=n<game['bankId']+0x100+len(buses) for n in ids)
manifest=dict(schemaVersion=1,id='independent.mhrise.wwise',name=game['title'],version='0.1.0',author='Independent adaptation / Codex',source='ApexAudio DevKit 0.1.0、当前游戏原文件、公开 RE Pak 格式实现与 wwiser；没有使用旧适配结果',description='Steam build 17920865；143 条普通总线，其中 142 条配置采集、主混音仅保留层级；细分语义待用户试听。',protocolVersion=1,entryPoint='ApexAudio.Wwise.exe',demo=False,games=[dict(executable=game['engineModule'],sha256=sha)],presets=['presets/initial.json'],files={})
preset=dict(schemaVersion=1,id='initial',name='初始配置（反馈默认关闭）',packId=manifest['id'],folders=[],groups={str(b['id']):dict(name=None,enabled=False,folderId=None,order=i) for i,b in enumerate(buses) if not b['auxiliary']})
evidence=definition/'evidence';evidence.mkdir(exist_ok=True)
for path,data in [(definition/'game.json',game),(definition/'manifest.json',manifest),(definition/'presets/initial.json',preset),(evidence/'bus-routing.json',rows)]:
    path.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
for which in ['base','patch']:
    data=json.loads((root/f'work/rise/metadata/{which}/extraction.json').read_text());(evidence/f'{which}-bank-extraction.json').write_text(json.dumps(data,indent=2),encoding='utf-8')
exports=json.loads((root/'work/rise/evidence/static.json').read_text(encoding='utf-8-sig'))['staticExports']
required=['?IsInitialized@SoundEngine@AK@@YA_NXZ','?GetAudioSettings@SoundEngine@AK@@YA?AW4AKRESULT@@AEAUAkAudioSettings@@@Z','?SetBusEffect@SoundEngine@AK@@YA?AW4AKRESULT@@III@Z','?LoadBankMemoryCopy@SoundEngine@AK@@YA?AW4AKRESULT@@PEBXIAEAI@Z','?RegisterPlugin@SoundEngine@AK@@YA?AW4AKRESULT@@W4AkPluginType@@IIP6APEAVIAkPlugin@2@PEAVIAkPluginMemAlloc@2@@ZP6APEAVIAkPluginParam@2@1@ZP6A?AW43@AEAIPEAUAkDeviceDescription@@@Z@Z','?RegisterGlobalCallback@SoundEngine@AK@@YA?AW4AKRESULT@@P6AXPEAVIAkGlobalPluginContext@2@W4AkGlobalCallbackLocation@@PEAX@ZI2W4AkPluginType@@II@Z','?UnregisterGlobalCallback@SoundEngine@AK@@YA?AW4AKRESULT@@P6AXPEAVIAkGlobalPluginContext@2@W4AkGlobalCallbackLocation@@PEAX@ZI@Z']
assert set(required)<=set(exports)
(evidence/'interface-evidence.json').write_text(json.dumps(dict(executableSha256=sha,requiredExports=required,bankVersion=140,selectedAbi='DevKit Wwise 2021.1 / bank 140',exactSdkBuild='not identified; compatible ABI must be validated in actual game',masterEffects=[0,1,2,3],metadataOnly=[b['id'] for b in buses if not b['auxiliary'] and b['slot']<0]),indent=2),encoding='utf-8')
print(json.dumps(dict(ordinary=sum(not b['auxiliary'] for b in buses),capture=sum(b['slot']>=0 for b in buses),auxiliary=sum(b['auxiliary'] for b in buses),sha256=sha)))
