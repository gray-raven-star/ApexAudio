# 独立调查复现

1. 先用用户提供的完整 DevKit 的 Setup、inspect 检查环境、当前 EXE、资源及实际运行模块。主程序导出的 Wwise 七项完整接口签名记录在 gamepacks/mhrise/evidence/interface-evidence.json。
2. 本次查阅 https://github.com/Ekey/REE.PAK.Tool 的公开格式原始实现；从其 Projects/MHR_STM_Release.list 确认资源路径 `natives/stm/sound/wwise/init.bnk.2.x64`。这是一份资源文件名清单，不是现成适配配置。
3. 从原仓库下载 `REE.Unpacker/REE.Unpacker/FileSystem/Encryption/PakCipher.cs` 供读取器核对公开索引格式常量。使用 Python 3.12，在本目录安装隔离的离线调查依赖：`python -m pip install --target python-deps --only-binary=:all: zstandard==0.25.0`。不改系统 Python。
4. 分别执行 `python read_re_pak.py <基础或补丁Pak路径> <临时输出目录> --cipher-reference <上述公开PakCipher.cs路径> natives/stm/sound/wwise/init.bnk.2.x64`。读取器只读取有界索引和指定的小文件，验证各记录文件范围和解压尺寸，拒绝不支持的资源加密及压缩。不是整包解压工具，也不修改 Pak。
5. 以补丁文件中的 Init.bnk 为准。从 https://github.com/bnnm/wwiser 下载公开原始源码，运行 `python wwiser.py <补丁Init.bnk路径> -d xml -dn <输出前缀>`；本次使用 v20260808，没有加载名称数据库。
6. 解析 CAkBus / CAkAuxBus：ulID 是总线 ID，OverrideBusId 是父组，BusInitialFxParams 下 uFXIndex 是已用槽。本次发现 143 条普通总线、67 条辅助组。普通主混音 3803692087 的槽 0/1/2/3 全满，保留元数据但不插入采集器；其余普通总线选静态空闲槽。对应证据见 bus-routing.json。
7. 使用 DevKit 已实现的 bank 140 / Wwise 2021.1 兼容路径。精确 SDK 补丁版本未知；并非仅凭版本号声称兼容，而是进一步实际通过插件注册、临时银行加载、挂接调用和真实 PCM 验证。
8. 根 README 的命令构建 .gpack；用 DevKit check --launch 和 native-check --entry CaptureSelfTest 分别确认协议及离线透传逻辑。它们不代替游戏验证。
9. 本次用户启动游戏后执行一次 `capture --allow-game-connection --seconds 6`，得到 3 条非零总线。详细结果和未验证范围在 gamepacks/mhrise/validation-report.json；没有继续要求用户进行动作分组测试。

新增内容为 game.json、manifest、预设、元数据读取器和文档。Wwise 后端与 DevKit 完全一致，没有主程序目标游戏分支。重建运行包不需要本目录的调查依赖。原始银行、Pak、EXE、游戏媒体和原始进程内存没有分发。


## 0.1.1 名称完善方法

此版仅修改 name、nameSource、category 和发布文档，未改变总线 ID/父组/效果槽/采集模块/游戏摘要。命名包结构与协议检查通过；不重复连接游戏做音频测试。

1. 对上一轮已读取的音频设置元数据字符串补做 Wwise FNV 对比，发现 bgm_lobby、bgm_quest_result 两个普通总线 ID 对应；这些字符串同时可能用作游戏状态，不把同名哈希当作完整语义试听证明。
2. 使用有限候选词汇（通用音频术语、当前游戏资源路径中的词、已命中类别前后缀）按小写 UTF-8 FNV-1 恢复名称。相同 ID 若出现多个不同的小写候选则不自动选取；本次没有这类歧义。大小写不可从哈希反推。
3. 核对恢复后的 PL_Master/PL_Wp/Wp_Whoosh/Wp_Impact、Enemy_Master/EM/EMS/VO/fo/fx、Otomo_Master/Airou/Dog、UI、BGM 等类别与实际 HIRC 父子层级相符。中文只是参考释义，不声称游戏原始名称为中文。
4. 143 条普通总线中 72 条有参考名（包括标准主混音、次级输出），71 条未恢复具体名称；能关联到已恢复父组的，显示该父组用途和原编号，来源里明确标注继承分类。
5. 完整对照、每个候选的来源和未试听状态见 evidence/name-restoration.json。没有下载其他游戏适配包、预置 Wwise 名称数据库或旧目标调查。

find_name_candidates.py、extend_name_candidates.py、apply_names.py、name_tree.py 保留原始任务的 work/rise 等相对目录用于审计。日常重建使用根 README 的现成定义即可；不用重新运行名称恢复脚本。
