# Wwise backend

See ../../docs/backend-configs.md, ../../docs/new-module.md and ../../docs/troubleshooting.md.
The native source describes supported layouts; no target game configuration is included.
