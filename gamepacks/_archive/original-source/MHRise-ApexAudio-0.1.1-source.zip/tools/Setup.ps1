param([string]$Compiler)
$ErrorActionPreference = 'Stop'
if (-not $IsWindows -or $PSVersionTable.PSVersion.Major -lt 7) { throw 'Use Windows x64 and PowerShell 7 (pwsh).' }
if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) { throw 'Install .NET 8 SDK: https://dotnet.microsoft.com/download/dotnet/8.0' }
$sdks = @(& dotnet --list-sdks)
if ($LASTEXITCODE -ne 0 -or -not ($sdks -match '^8\.')) { throw '.NET 8 SDK is required. A runtime alone is not sufficient.' }
. (Join-Path $PSScriptRoot 'FindCompiler.ps1')
$zig = Resolve-ApexCompiler $Compiler
[ordered]@{ platform='windows-x64'; sdk8=$true; compiler=$zig; compilerVersion=(& $zig version); networkDownloadPerformed=$false } | ConvertTo-Json
